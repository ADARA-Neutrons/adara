#====================================================================
#  NeXus - Neutron & X-ray Common Data Format
#  
#  $Id: Makefile.am 961 2007-09-04 12:31:49Z Freddie Akeroyd $
#
#  Python functions to assist with scons build
#  
#  Copyright (C) 2008 Freddie Akeroyd
#  
#  This library is free software; you can redistribute it and/or
#  modify it under the terms of the GNU Lesser General Public
#  License as published by the Free Software Foundation; either
#  version 2 of the License, or (at your option) any later version.
# 
#  This library is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#  Lesser General Public License for more details.
# 
#  You should have received a copy of the GNU Lesser General Public
#  License along with this library; if not, write to the Free 
#  Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, 
#  MA  02111-1307  USA
#             
#  For further information, see <http://www.nexusformat.org/>
#
#====================================================================

import os
import platform
import sys
import shutil
from socket import gethostname

# return a list with the correct shared object suffix
def getSharedObjects(sources, env) :
    shared_objects = []
    for f in sources :
        shared_objects.append(os.path.splitext(f)[0]+env['SHOBJSUFFIX'])
    return shared_objects
