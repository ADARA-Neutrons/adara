#ifndef NX_STPTOK
#define NX_STPTOK

extern char *stptok(const char *s, char *tok, size_t toklen, char *brk);

#endif /* NX_STPTOK */